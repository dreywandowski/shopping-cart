<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Shopping Cart</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" type="text/css" href="/css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="/css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- fonts -->
      <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
      <!-- font awesome -->
      <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <!--  -->
      <!-- owl stylesheets -->
      <link href="https://fonts.googleapis.com/css?family=Great+Vibes|Poppins:400,700&display=swap&subset=latin-ext" rel="stylesheet">
      <link rel="stylesheet" href="/css/owl.carousel.min.css">
      <link rel="stylesoeet" href="/css/owl.theme.default.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
   </head>
   <body>
<p> List of orders by user</p>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div>
      <?php echo e($order->id); ?>----
      <?php echo e($order->user); ?>

   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- banner bg main start -->
      <div class="banner_bg_main">
         <!-- header top section start -->
         <div class="container">
            
         </div>
         <!-- header top section start -->
         <!-- logo section start -->
         <div class="logo_section">
            <div class="container">
               <div class="row">
                  
               </div>
            </div>
         </div>
         <!-- logo section end -->
         <!-- header section start -->
         <div class="header_section">
            <div class="container">
               <div class="containt_main">
                  <div id="mySidenav" class="sidenav">
                     <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                     <a href="index.html">Home</a>
                     <a href="fashion.html">Fashion</a>
                     <a href="electronic.html">Electronic</a>
                     <a href="jewellery.html">Jewellery</a>
                  </div>
                  
                  <div class="dropdown">
                     
                     
                  </div>
                  <div class="main">
                     <!-- Another variation with a button -->
                     <div class="input-group">
                        <div class="col-sm-12">
                              <h1 class="banner_taital"><br>Your favourite one-stop shop for online shopping</h1>
                              <div class="buynow_bt"><a href="#fash">Buy Now</a></div>
                           </div>
                        
                     </div>
                  </div>
                  <div class="header_box">
                     <div class="lang_box ">
                        
                        <div class="dropdown-menu ">
                           <a href="#" class="dropdown-item">
                           <img src="/images/flag-france.png" class="mr-2" alt="flag">
                           French
                           </a>
                        </div>
                     </div>
                     <div class="login_menu">
                        <ul>
                           
                           <li><a href="#">
                              <i class="fa fa-user" aria-hidden="true"></i>
                              <span class="padding_10">Cart</span></a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- header section end -->
         <!-- banner section start -->
         <div class="banner_section layout_padding">
            <div class="container">
               <div id="my_slider" class="carousel slide" data-ride="carousel">
                  <div class="carousel-inner">
                     <div class="carousel-item active">
                        <div class="row">
                           
                        </div>
                     </div>
                     
                     </div>
                     <div class="carousel-item">
                        <div class="row">
                           <div class="col-sm-12">
                              <h1 class="banner_taital">Get Started <br>Your favourite shoping</h1>
                              <div class="buynow_bt"><a href="#">Buy Now</a></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <a class="carousel-control-prev" href="#my_slider" role="button" data-slide="prev">
                  <i class="fa fa-angle-left"></i>
                  </a>
                  <a class="carousel-control-next" href="#my_slider" role="button" data-slide="next">
                  <i class="fa fa-angle-right"></i>
                  </a>
               </div>
            </div>
         </div>
         <!-- banner section end -->
      </div>
      <!-- banner bg main end -->
      <!-- fashion section start -->
      <div class="fashion_section">
         <div id="main_slider" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container">
                     <h1 class="fashion_taital" id="fash">Men & Women Fashion</h1>
                     <div class="fashion_section_2">
                        <div class="row">
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Men's T -shirt</h4>
                                 <p class="price_text">Price  <span style="color: #262626;">NGN 5000</span></p>
                                 <div class="tshirt_img"><img src="/images/tshirt-img.png"></div>
                                 <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Men's T -shirt</h4>
                                 <p class="price_text">Price  <span style="color: #262626;">NGN 7000</span></p>
                                 <div class="tshirt_img"><img src="/images/dress-shirt-img.png"></div>
                                 <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                    <!--<div><input type="text" class="seemore_bt" placeholder="type in discount code here"><a href="#" class="buy_bt">Apply discount</a></div>-->
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Women's Scarf</h4>
                                 <p class="price_text">Price  <span style="color: #262626;">NGN 8000</span></p>
                                 <div class="tshirt_img"><img src="/images/women-clothes-img.png"></div>
                                 <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                              </div>
                           </div>
                        </div>
                    
      <!-- fashion section end -->
      <!-- electronic section start -->
      <div class="fashion_section">
         <div id="electronic_main_slider" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container">
                     <h1 class="fashion_taital">Electronics</h1>
                     <div class="fashion_section_2">
                        <div class="row">
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Laptop</h4>
                                 <p class="price_text"> Price  <span style="color: #262626;">NGN 150, 000</span></p>
                                 <div class="electronic_img"><img src="/images/laptop-img.png"></div>
                                 <div class="btn_main">
                                    <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Mobile</h4>
                                 <p class="price_text"> Price  <span style="color: #262626;">NGN 90, 000</span></p>
                                 <div class="electronic_img"><img src="/images/mobile-img.png"></div>
                                 <div class="btn_main">
                                    <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Computers</h4>
                                 <p class="price_text"> Price  <span style="color: #262626;">NGN 270, 000</span></p>
                                 <div class="electronic_img"><img src="/images/computer-img.png"></div>
                                 <div class="btn_main">
                                   <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            
      <!-- electronic section end -->
      <!-- jewellery  section start -->
      <div class="jewellery_section">
         <div id="jewellery_main_slider" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container">
                     <h1 class="fashion_taital">Jewellery Accessories</h1>
                     <div class="fashion_section_2">
                        <div class="row">
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Jumkas</h4>
                                 <p class="price_text"> Price  <span style="color: #262626;">NGN 3000</span></p>
                                 <div class="jewellery_img"><img src="/images/jhumka-img.png"></div>
                                 <div class="btn_main">
                                   <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Necklaces</h4>
                                 <p class="price_text"> Price  <span style="color: #262626;">NGN 8000</span></p>
                                 <div class="jewellery_img"><img src="/images/neklesh-img.png"></div>
                                 <div class="btn_main">
                                    <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-sm-4">
                              <div class="box_main">
                                 <h4 class="shirt_text">Kangans</h4>
                                 <p class="price_text">Price  <span style="color: #262626;">NGN 2000</span></p>
                                 <div class="jewellery_img"><img src="/images/kangan-img.png"></div>
                                 <div class="btn_main">
                                   <div class="btn_main">
                                    <div class="buy_bt"><a href="#">Add to Cart</a></div>
                                   
                                 </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
             
            <!--<a class="carousel-control-prev" href="#jewellery_main_slider" role="button" data-slide="prev">
            <i class="fa fa-angle-left"></i>
            </a>
            <a class="carousel-control-next" href="#jewellery_main_slider" role="button" data-slide="next">
            <i class="fa fa-angle-right"></i>
            </a>
            <div class="loader_main">
               <div class="loader"></div>
            </div>-->
         </div>
      </div>
      <!-- jewellery  section end -->
      <!-- footer section start -->
      <footer class="footer_section layout_padding">
         <div class="container">
           <center> <p> Developed by dreywandowski</p></center>
      <!-- footer section end -->
      <!-- copyright section start -->
      
      </footer>
      <!-- copyright section end -->
      <!-- Javascript files-->
      <script src="/js/jquery.min.js"></script>
      <script src="/js/popper.min.js"></script>
      <script src="/js/bootstrap.bundle.min.js"></script>
      <script src="/js/jquery-3.0.0.min.js"></script>
      <script src="/js/plugin.js"></script>
      <!-- sidebar -->
      <script src="/js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="/js/custom.js"></script>
      <script>
         function openNav() {
           document.getElementById("mySidenav").style.width = "250px";
         }
         
         function closeNav() {
           document.getElementById("mySidenav").style.width = "0";
         }
      </script>
   </body>
</html><?php /**PATH C:\wamp64\www\shopping-cart\resources\views/shop.blade.php ENDPATH**/ ?>