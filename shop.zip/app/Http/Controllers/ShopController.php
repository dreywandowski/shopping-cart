<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Orders;

class ShopController extends Controller
{
	// this is for the home page of the app
    public function index () {

    	$orders = Orders::all();

    return view('shop', [
    	'orders' => $orders
    ]);
}
}
