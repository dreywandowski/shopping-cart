

## E-commerce system

# A simple web app built to simulate an e-commerce system


